#include "qemu/osdep.h"
#include "qemu/module.h"

void qemu_module_dummy(void)
{
}

void DSO_STAMP_FUN(void)
{
}
