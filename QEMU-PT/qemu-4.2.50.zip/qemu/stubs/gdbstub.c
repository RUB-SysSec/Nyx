#include "qemu/osdep.h"
#include "exec/gdbstub.h"       /* xml_builtin */

const char *const xml_builtin[][2] = {
  { NULL, NULL }
};
