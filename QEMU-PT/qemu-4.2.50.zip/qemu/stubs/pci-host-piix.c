#include "qemu/osdep.h"
#include "hw/pci-host/i440fx.h"

PCIBus *find_i440fx(void)
{
    return NULL;
}
