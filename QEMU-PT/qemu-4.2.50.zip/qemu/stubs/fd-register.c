#include "qemu/osdep.h"
#include "qemu/main-loop.h"

void qemu_fd_register(int fd)
{
}
