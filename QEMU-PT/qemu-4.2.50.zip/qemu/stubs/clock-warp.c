#include "qemu/osdep.h"
#include "qemu/timer.h"

void qemu_start_warp_timer(void)
{
}

