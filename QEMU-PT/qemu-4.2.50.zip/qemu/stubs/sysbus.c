#include "qemu/osdep.h"
#include "hw/qdev-core.h"

BusState *sysbus_get_default(void)
{
    return NULL;
}
